# """Create datasets for training and testing."""
# import csv
# import os
# import random
#
# import click
#
#
# import cyclegan_datasets
# import numpy as np
#
# def get_label_list(file_):
#     # return:
#     #  [[1 1 0 ... 1 0 0]
#     #  ...
#     #  [1 1 0 ... 1 0 0]]
#     with open(file_)  as f:
#         lines = []
#         line = f.readline()
#         while line:
#             lines.append(line.split('\n')[0])
#             line = f.readline()
#     lines = [[int(number) for number in line] for line in lines]
#     return np.array(lines)
#
# @click.command()
#
# # @click.option('--label_path_a',
# #               type=click.STRING,
# #               default='./input/shuimo_easy/trainLabel/trainA1.txt',
# #               help='The path to the label from image_a.')
# # @click.option('--label_path_b',
# #               type=click.STRING,
# #               default='./input/shuimo_easy/trainLabel/trainB1.txt',
# #               help='The path to the label from image_b.')
# # @click.option('--label_name',
# #               type=click.STRING,
# #               default='./input/shuimo_easy/shuimo_label.csv',
# #               help='The name of the dataset label in cyclegan_dataset.')
# @click.option('--dataset_name',
#               type=click.STRING,
#               default='shuimo_easy_train',
#               help='The name of the dataset in cyclegan_dataset.')
# @click.option('--do_shuffle',
#               type=click.BOOL,
#               default=False,
#               help='Whether to shuffle images when creating the dataset.')
#
#
# # def create_label_datasets(label_path_a,label_path_b,
# #                     dataset_name,label_name,do_shuffle):
# #     list_label_a=get_label_list(label_path_a)
# #     list_label_b=get_label_list(label_path_b)
# #
# #     output_label_path=label_name
# #
# #     num_rows = cyclegan_datasets.DATASET_TO_SIZES[dataset_name]
# #     all_label_tuples=[]
# #     for i in range(num_rows):
# #         all_label_tuples.append((
# #             list_label_a[i%len(list_label_a)],
# #             list_label_b[i%len(list_label_b)]
# #         ))
# #     if do_shuffle is True:
# #         random.shuffle(all_label_tuples)
# #
# #     with open(output_label_path, 'w') as csv_file:
# #         csv_writer = csv.writer(csv_file)
# #         for label_tuple in enumerate(all_label_tuples):
# #             #print(label_tuple)
# #             # label_tuple_data=str(list(label_tuple), encoding='utf-8').strip('\n').split(',')
# #             csv_writer.writerow(label_tuple[1])
#     # with open(label_a, 'w' ) as csvfile:
#     #     # 编码风格，默认为excel方式，也就是逗号(,)分隔
#     #     spamwriter = csv.writer( csvfile, dialect='excel' )
#     #     # 读取txt文件，每行按逗号分割提取数据
#     #     with open( label_path_a, 'r' ) as file_txt:
#     #         for line in file_txt:
#     #             line_datas = line.strip( '\n' ).split( ',' )
#     #             spamwriter.writerow( line_datas )
#     # with open(label_b, 'w' ) as csvfile:
#     #     # 编码风格，默认为excel方式，也就是逗号(,)分隔
#     #     spamwriter = csv.writer( csvfile, dialect='excel' )
#     #     # 读取txt文件，每行按逗号分割提取数据
#     #     with open( label_path_b, 'r' ) as file_txt:
#     #         for line in file_txt:
#     #             line_datas = line.strip( '\n' ).split( ',' )
#     #             spamwriter.writerow( line_datas )
# def create_label_a(label_path_a,label_name,do_shuffle):
#     list_label_a=get_label_list(label_path_a)
#
#     output_label_path=label_name
#
#     num_rows = 201
#     all_label_tuples=[]
#     for i in range(num_rows):
#         all_label_tuples.append((
#             list_label_a[i%len(list_label_a)]
#         ))
#     if do_shuffle is True:
#         random.shuffle(all_label_tuples)
#
#     with open(output_label_path, 'w') as csv_file:
#         csv_writer = csv.writer(csv_file)
#         for label_tuple in enumerate(all_label_tuples):
#             #print(label_tuple)
#             # label_tuple_data=str(list(label_tuple), encoding='utf-8').strip('\n').split(',')
#             csv_writer.writerow(label_tuple[1])
#
# def create_label_b(label_path_b,label_name,do_shuffle):
#     list_label_b=get_label_list(label_path_b)
#
#     output_label_path=label_name
#
#     num_rows = 201
#     all_label_tuples=[]
#     for i in range(num_rows):
#         all_label_tuples.append((
#             list_label_b[i%len(list_label_b)]
#         ))
#     if do_shuffle is True:
#         random.shuffle(all_label_tuples)
#
#     with open(output_label_path, 'w') as csv_file:
#         csv_writer = csv.writer(csv_file)
#         for label_tuple in enumerate(all_label_tuples):
#             #print(label_tuple)
#             # label_tuple_data=str(list(label_tuple), encoding='utf-8').strip('\n').split(',')
#             csv_writer.writerow(label_tuple[1])
# if __name__ == '__main__':
#     create_label_a(label_path_a='G:/python3.6/trainLabel/trainA1.txt',label_name='G:/python3.6/label_a.csv',do_shuffle=0)
#     create_label_b( label_path_b='G:/python3.6/trainLabel/trainB1.txt',
#                     label_name='G:/python3.6/label_b.csv', do_shuffle=0 )
