"""Contains the standard train/test splits for the cyclegan data."""

"""The size of each dataset. Usually it is the maximum number of images from
each domain."""
DATASET_TO_SIZES = {
    # 'shuimo_train': 1118,
    # 'shuimo_test': 471,
    'shuimo_train':2000,#1560
    'shuimo_test': 493,
    'gongbi_train': 2000,
    'gongbi_test':600,
    # 'horse2zebra_train': 1334,
    # 'horse2zebra_test': 140,
    # 'apple2orange_train': 1019,
    # 'apple2orange_test': 266,
    # 'lion2tiger_train': 916,
    # 'lion2tiger_test': 103,
    # 'summer2winter_yosemite_train': 1231,
    # 'summer2winter_yosemite_test': 309,
}

"""The image types of each dataset. Currently only supports .jpg or .png"""
DATASET_TO_IMAGETYPE = {
    # 'shuimo_train': '.jpg',
    # 'shuimo_test': '.jpg',
    'shuimo_train': '.jpg',
    'gongbi_train':'.jpg',
    'gongbi_test':'.jpg',
    'shuimo_test': '.jpg',
    # 'horse2zebra_train': '.jpg',
    # 'horse2zebra_test': '.jpg',
    # 'apple2orange_train': '.jpg',
    # 'apple2orange_test': '.jpg',
    # 'lion2tiger_train': '.jpg',
    # 'lion2tiger_test': '.jpg',
    # 'summer2winter_yosemite_train': '.jpg',
    # 'summer2winter_yosemite_test': '.jpg',
}

"""The path to the output csv file."""
PATH_TO_CSV = {
    # 'shuimo_train': './input/shuimo/shuimo_train.csv',
    'shuimo_test': './input/shuimo/shuimo_test.csv',
    'shuimo_train': './input/shuimo/shuimo_train.csv',
    'gongbi_train': './input/gongbi/gongbi_train.csv',
    'gongbi_test':'./input/gongbi/gongbi_test.csv',
    'shuimo_label':'/input/shuimo_easy/shuimo_label.csv',
    #'shuimo_test1': './input/shuimo/shuimo_test1.csv',
    # 'horse2zebra_train': './input/horse2zebra/horse2zebra_train.csv',
    # 'horse2zebra_test': './input/horse2zebra/horse2zebra_test.csv',
    # 'apple2orange_train': './datasets/apple2orange/apple2orange_train.csv',
    # 'apple2orange_test': './datasets/apple2orange/apple2orange_test.csv',
    # 'lion2tiger_train': './input/lion2tiger/lion2tiger_train.csv',
    # 'lion2tiger_test': './input/lion2tiger/lion2tiger_test.csv',
    # 'summer2winter_yosemite_train': './input/summer2winter_yosemite/summer2winter_yosemite_train.csv',
    # 'summer2winter_yosemite_test': './input/summer2winter_yosemite/summer2winter_yosemite_test.csv'

}
