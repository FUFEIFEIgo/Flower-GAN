"""Contains losses used for performing image-to-image domain adaptation."""
import scipy.misc

import tensorflow as tf
import numpy as np

def cycle_consistency_loss(real_images, generated_images):
    return tf.reduce_mean(tf.abs(real_images - generated_images))

def l1_loss(src, dst): #定义l1_loss
    return tf.reduce_mean(tf.abs(src - dst))

def mask_loss(gen_image, mask):

    return tf.reduce_mean(tf.abs(tf.multiply(gen_image,1-mask)))

def lsgan_loss_generator(prob_fake_is_real):
    return tf.reduce_mean(tf.squared_difference(prob_fake_is_real,1))

def lsgan_loss_discriminator(prob_real_is_real, prob_fake_is_real):

    return (tf.reduce_mean(tf.squared_difference(prob_real_is_real, 1)) +
            tf.reduce_mean(tf.squared_difference(prob_fake_is_real, 0))) * 0.5

# # mask_loss_a=losses.mask_loss(gen_image=self.fake_images_a,mask=self.masks[1])
#         # mask_loss_b=losses.mask_loss(gen_image=self.fake_images_b,mask=self.masks[0])
#
#         # gen_loss_L1_a=tf.reduce_mean(losses.l1_loss(src=self.fake_images_a,dst=self.label_b))
#         # gen_loss_L1_b=tf.reduce_mean(losses.l1_loss(src=self.fake_images_b,dst=self.label_a))
#
#         ssim_a =0.3* tf.reduce_mean( tf.image.ssim_multiscale( self.input_a, self.cycle_images_a, 1.0 ))
#         ssim_b =0.3* tf.reduce_mean( tf.image.ssim_multiscale( self.input_b, self.cycle_images_b, 1.0 ))
#         # label loss
#         ####修改过
#         g_loss_A = (cycle_consistency_loss_a+ cycle_consistency_loss_b+ssim_a+ssim_b)*0.5+lsgan_loss_b #+gen_loss_L1_b# +l1_loss_a
#         g_loss_B = (cycle_consistency_loss_b + cycle_consistency_loss_a+ssim_a+ssim_b )*0.5+lsgan_loss_a#+gen_loss_L1_a# +l1_loss_b