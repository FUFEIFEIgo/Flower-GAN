"""Create datasets for training and testing."""
import csv
import os
import random

import click


import dataset



def create_list(foldername, fulldir=True, suffix=".jpg"):
    """

    :param foldername: The full path of the folder.
    :param fulldir: Whether to return the full path or not.
    :param suffix: Filter by suffix.

    :return: The list of filenames in the folder with given suffix.

    """
    file_list_tmp = os.listdir(foldername)
    file_list = []
    if fulldir:
        for item in file_list_tmp:
            if item.endswith(suffix):
                file_list.append(os.path.join(foldername, item))
    else:
        for item in file_list_tmp:
            if item.endswith(suffix):
                file_list.append(item)
    return file_list

# def get_label_list(filename):
#     f=open(filename,'r')
#     lines=f.readlines()
#     f.close()
#     return lines

@click.command()
@click.option('--image_path_a',
              type=click.STRING,
              default='./input/shuimo/trainPicture/trainA1',
              help='The path to the images from domain_a.')
@click.option('--image_path_b',
              type=click.STRING,
              default='./input/shuimo/trainPicture/trainB1',
              help='The path to the images from domain_b.')
#
# @click.option('--label_path_a',
#               type=click.STRING,
#               default='./input/shuimo_easy/trainLabel/trainA1.txt',
#               help='The path to the label from image_a.')
# @click.option('--label_path_b',
#               type=click.STRING,
#               default='./input/shuimo_easy/trainLabel/trainB1.txt',
#               help='The path to the label from image_b.')
# @click.option('--label_name',
#               type=click.STRING,
#               default='shuimo_label',
#               help='The name of the dataset label in cyclegan_dataset.')
@click.option('--dataset_name',
              type=click.STRING,
              default='shuimo_train',
              help='The name of the dataset in cyclegan_dataset.')
@click.option('--do_shuffle',
              type=click.BOOL,
              default=False,
              help='Whether to shuffle images when creating the dataset.')


def create_dataset(image_path_a, image_path_b,
                   dataset_name,do_shuffle):
    list_a = create_list( image_path_a, True,
                          dataset.DATASET_TO_IMAGETYPE[dataset_name] )
    list_b = create_list( image_path_b, True,
                          dataset.DATASET_TO_IMAGETYPE[dataset_name] )
    # list_label_a=get_label_list(label_path_a)
    # list_label_b=get_label_list(label_path_b)

    output_path = dataset.PATH_TO_CSV[dataset_name]

    # output_label_path=cyclegan_datasets.PATH_TO_CSV[label_name]

    num_rows = dataset.DATASET_TO_SIZES[dataset_name]
    all_data_tuples = []
    # all_label_tuples=[]
    for i in range(num_rows):
        all_data_tuples.append((
            list_a[i % len(list_a)],
            list_b[i % len(list_b)]
        ))
        # all_label_tuples.append((
        #     list_label_a[i%len(list_label_a)],
        #     list_label_b[i % len( list_label_b )]
        # ))
    if do_shuffle is True:
        random.shuffle(all_data_tuples)
        # random.shuffle(all_label_tuples)

    with open(output_path, 'w') as csv_file:
        csv_writer = csv.writer(csv_file)
        for data_tuple in enumerate(all_data_tuples):
            csv_writer.writerow(list(data_tuple[1]))
    #
    # with open(output_label_path, 'wb') as csv_file:
    #     csv_writer = csv.writer(csv_file)
    #     for label_tuple in enumerate(all_label_tuples):
    #         csv_writer.writerow(list(label_tuple[1]))
    # with open(label_a, 'w' ) as csvfile:
    #     # 编码风格，默认为excel方式，也就是逗号(,)分隔
    #     spamwriter = csv.writer( csvfile, dialect='excel' )
    #     # 读取txt文件，每行按逗号分割提取数据
    #     with open( label_path_a, 'r' ) as file_txt:
    #         for line in file_txt:
    #             line_datas = line.strip( '\n' ).split( ',' )
    #             spamwriter.writerow( line_datas )
    # with open(label_b, 'w' ) as csvfile:
    #     # 编码风格，默认为excel方式，也就是逗号(,)分隔
    #     spamwriter = csv.writer( csvfile, dialect='excel' )
    #     # 读取txt文件，每行按逗号分割提取数据
    #     with open( label_path_b, 'r' ) as file_txt:
    #         for line in file_txt:
    #             line_datas = line.strip( '\n' ).split( ',' )
    #             spamwriter.writerow( line_datas )

if __name__ == '__main__':
    create_dataset()
