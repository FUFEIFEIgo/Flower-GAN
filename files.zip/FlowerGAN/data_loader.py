# import csv
# from _csv import reader
#
# import tensorflow as tf
#
# import dataset
# import model
# import numpy as np
#
#
# def _load_samples(csv_name,image_type):
#     image_decoded_A=[]
#     image_decoded_B=[]
#
#     filename_queue = tf.train.string_input_producer([csv_name])
#     #file2name_queue=tf.train.string_input_producer([csv_label_name])
#
#     reader = tf.TextLineReader()
#     _, csv_filename = reader.read(filename_queue)
#     # _,csv_file2name=reader.read(file2name_queue)
#
#     record_defaults = [tf.constant([], dtype=tf.string),
#                        tf.constant([], dtype=tf.string)]
#
#     filename_i, filename_j = tf.decode_csv(
#         csv_filename, record_defaults=record_defaults)
#
#     file_contents_i = tf.read_file(filename_i)
#     file_contents_j = tf.read_file(filename_j)
#
#     if image_type == '.jpg':
#         image_decoded_A = tf.image.decode_jpeg(file_contents_i, channels=model.IMG_CHANNELS)
#         image_decoded_B = tf.image.decode_jpeg(file_contents_j, channels=model.IMG_CHANNELS)
#     elif image_type == '.png':
#         image_decoded_A = tf.image.decode_png(
#         file_contents_i, channels=model.IMG_CHANNELS, dtype=tf.uint8)
#         image_decoded_B = tf.image.decode_png(
#         file_contents_j, channels=model.IMG_CHANNELS, dtype=tf.uint8)
#     return image_decoded_A, image_decoded_B
#
# # def __load_label(label_a):
# #
# #     file2name_queue = tf.train.input_producer([label_a] )
# #     reader = tf.TextLineReader()
# #     key,value= reader.read(file2name_queue)
# #     #record_defaults = [[1],[1]]# 这里的数据类型决定了读取的数据类型，而且必须是list形式
# #     record_defaults = [tf.constant( [], dtype=tf.int32)]
# #     label_i=tf.decode_csv(value,record_defaults=record_defaults)# 解析出的每一个属性都是rank为0的标量
# #     # label_i=tf.sparse_tensor_to_dense(label_i)
# #     # label_j=tf.sparse_tensor_to_dense(label_j)
# #     # label_i=tf.data.TextLineDataset(label_i)
# #     # label_j=tf.data.TextLineDataset(label_j)
# #     # iterator = label_i.make_initializable_iterator()
# #     # label_i_ = iterator.get_next()
# #     # iterator1 = label_j.make_initializable_iterator()
# #     # label_j_ = iterator1.get_next()
# #     return  label_i
#
# # def Split(Str):
# #     "字符串切割"
# #     List=[]
# #     i=0
# #     while i<len(Str):#shape
# #         List.insert(i, Str[i])
# #         i+=1
# #     return List
#
# def _load_label(label_name):
#     csv_file=open(label_name,'r')
#     reader=csv.reader(csv_file)
#     list=[]
#     i=0
#     for line in reader:
#         if(i%2==0):
#            list.append(line)
#         i+=1
#     return list
#
#
# def load_data(dataset_name,label_a_csv,label_b_csv,image_size_before_crop,
#               do_shuffle=False, do_flipping=False):
#     """
#
#     :param dataset_name: The name of the dataset.
#     :param image_size_before_crop: Resize to this size before random cropping.
#     :param do_shuffle: Shuffle switch.
#     :param do_flipping: Flip switch.
#     :return:
#     """
#     if dataset_name not in cyclegan_datasets.DATASET_TO_SIZES:
#         raise ValueError('split name %s was not recognized.'
#                          % dataset_name)
#
#     csv_name = cyclegan_datasets.PATH_TO_CSV[dataset_name]
#     # csv_label_name='./input/shuimo_easy/shuimo_label.csv'
#     # label_a='./input/shuimo_easy/label_a.csv'
#     # label_b='./input/shuimo_easy/label_b.csv'
#
#     image_i, image_j= _load_samples(
#         csv_name,cyclegan_datasets.DATASET_TO_IMAGETYPE[dataset_name])
#
#     label_i=_load_label(label_a_csv)
#     label_j = _load_label( label_b_csv )
#     # label_i=__load_label(label_a_csv)
#     # label_j=__load_label(label_b_csv)
#
#     # label_i=labels[0:16]
#     # label_j=labels[1]
#    # print('label_i:::',label_i)
#
#     inputs = {
#         'image_i': image_i,
#         'image_j': image_j,
#         'label_i':label_i,
#         'label_j':label_j,
#     }
#     # Preprocessing:
#     inputs['image_i'] = tf.image.resize_images(
#         inputs['image_i'], [image_size_before_crop, image_size_before_crop])
#     inputs['image_j'] = tf.image.resize_images(
#         inputs['image_j'], [image_size_before_crop, image_size_before_crop])
#
#     # #label预处理
#     # a=Split(label_i)
#     # b = tf.reshape( label_i, shape=[1, 1, 1, 16] )
#     # b = tf.cast( b, tf.float32 )
#     # c = np.tile( b, [1, 384, 384, 1] )
#     # inputs['label_i']=c
#     # #
#     # a1 = Split( label_i )
#     # b1 = tf.reshape( label_j, shape=[1, 1, 1, 16] )
#     # b1 = tf.cast( b1, tf.float32 )
#     # c1 = np.tile( b1, [1, 384, 384, 1] )
#     # inputs['label_j']=c1
#
#     if do_flipping is True:
#         inputs['image_i'] = tf.image.random_flip_left_right(inputs['image_i'], seed=1)
#         inputs['image_j'] = tf.image.random_flip_left_right(inputs['image_j'], seed=1)
#
#     inputs['image_i'] = tf.random_crop(
#         inputs['image_i'], [model.IMG_HEIGHT, model.IMG_WIDTH, 3], seed=1)
#     inputs['image_j'] = tf.random_crop(
#         inputs['image_j'], [model.IMG_HEIGHT, model.IMG_WIDTH, 3], seed=1)
#
#     inputs['image_i'] = tf.subtract(tf.div(inputs['image_i'], 127.5), 1)
#     inputs['image_j'] = tf.subtract(tf.div(inputs['image_j'], 127.5), 1)
#
#
#     # Batch
#     if do_shuffle is True:
#         inputs['images_i'], inputs['images_j'],inputs['labels_i'],inputs['labels_j'] = tf.train.shuffle_batch(
#             [inputs['image_i'], inputs['image_j'],inputs['label_i'],inputs['label_j']], 1, 5000, 100, seed=1)
#     else:
#         inputs['images_i'], inputs['images_j']= tf.train.batch([inputs['image_i'], inputs['image_j']],1)#
#
#         inputs['labels_i'],inputs['labels_j']=tf.train.batch([inputs['label_i'],inputs['label_j']],1)
#     return inputs
#
# # def load_label(label_a_name,label_b_name):
# #      label_a_Mat=[],label_b_Mat=[]
# #      fr_a=open(label_a_name)
# #      fr_b=open(label_b_name)
# #      for line in fr_a.readlines():
# #          lineArr_a=line.strip().split('\t')
# #          label_a_Mat.append(list(map(int,lineArr_a[:])))
# #      for line in fr_b.readlines():
# #          lineArr_b=line.strip().split('\t')
# #          label_b_Mat.append(list(map(int,lineArr_b[0:])))
# #      return label_a_Mat,label_b_Mat
# # def preprocess_label(filename):
# #     fr=open(filename)
# #     array=[]
# #     for line in fr.readlines():
# #         lineArr=line.strip().split('\t')
# #         lineArr=tf.concat([lineArr]*24,axis=1)
# #         lineArr=tf.concat([lineArr]*384,axis=2)
# #         array.append(list(map(float,lineArr[0:][0:])))
# #     return array


import glob
import os

import tensorflow as tf

import dataset
import model


def _load_samples(csv_name,image_type):
    image_decoded_A=[]
    image_decoded_B=[]
    image_decoded_SB=[]

    filename_queue = tf.train.string_input_producer([csv_name])
    #filename_queue=tf.train.string_input_producer([csv_name])

    reader = tf.TextLineReader()
    _, csv_filename = reader.read(filename_queue)
    #_,csv_filename=reader.read(filename_queue)

    record_defaults = [tf.constant([], dtype=tf.string),
                       tf.constant([], dtype=tf.string)]
    # record_defaults = [tf.constant( [], dtype=tf.string ),
    #                     tf.constant( [], dtype=tf.string ),
    #                     tf.constant( [], dtype=tf.string )]

    filename_i, filename_j = tf.decode_csv(
        csv_filename, record_defaults=record_defaults)

    # filename_i, filename_j,filename_k= tf.decode_csv(
    #     csv_filename, record_defaults=record_defaults )

    file_contents_i = tf.read_file(filename_i)
    file_contents_j = tf.read_file(filename_j)
    #file_contents_k=tf.read_file(filename_k)

    if image_type == '.jpg':
        image_decoded_A = tf.image.decode_jpeg( file_contents_i, channels=model.IMG_CHANNELS )
        image_decoded_B = tf.image.decode_jpeg( file_contents_j, channels=model.IMG_CHANNELS )
        #image_decoded_SB = tf.image.decode_jpeg(file_contents_k, channels=model.IMG_CHANNELS)
    elif image_type == '.png':
        image_decoded_A = tf.image.decode_png(
        file_contents_i, channels=model.IMG_CHANNELS, dtype=tf.uint8)
        image_decoded_B = tf.image.decode_png(
        file_contents_j, channels=model.IMG_CHANNELS, dtype=tf.uint8)
        # image_decoded_SB = tf.image.decode_png(
        #     file_contents_k, channels=model.IMG_CHANNELS, dtype=tf.uint8 )
    return image_decoded_A, image_decoded_B


def load_data(dataset_name, image_size_before_crop,
              do_shuffle=True, do_flipping=False):
    """

    :param dataset_name: The name of the dataset.
    :param image_size_before_crop: Resize to this size before random cropping.
    :param do_shuffle: Shuffle switch.
    :param do_flipping: Flip switch.
    :return:
    """
    if dataset_name not in dataset.DATASET_TO_SIZES:
        raise ValueError('split name %s was not recognized.'
                         % dataset_name)

    csv_name = dataset.PATH_TO_CSV[dataset_name]

    image_i, image_j = _load_samples(
        csv_name, dataset.DATASET_TO_IMAGETYPE[dataset_name])
    #
    # image_i, image_j ,image_k= _load_samples(
    #     csv_name, cyclegan_datasets.DATASET_TO_IMAGETYPE[dataset_name] )
    # inputs = {
    #     'image_i': image_i,
    #     'image_j': image_j
    # }
    inputs = {
        'image_i': image_i,
        'image_j': image_j,
        #'image_k':image_k
    }

    # Preprocessing:
    inputs['image_i'] = tf.image.resize_images(
        inputs['image_i'], [image_size_before_crop, image_size_before_crop])
    inputs['image_j'] = tf.image.resize_images(
        inputs['image_j'], [image_size_before_crop, image_size_before_crop])
    # inputs['image_k'] = tf.image.resize_images(
    #     inputs['image_k'], [image_size_before_crop, image_size_before_crop] )

    if do_flipping is True:
        inputs['image_i'] = tf.image.random_flip_left_right(inputs['image_i'], seed=1)
        inputs['image_j'] = tf.image.random_flip_left_right(inputs['image_j'], seed=1)
        #inputs['image_k'] = tf.image.random_flip_left_right( inputs['image_k'], seed=1 )

    inputs['image_i'] = tf.random_crop(
        inputs['image_i'], [model.IMG_HEIGHT, model.IMG_WIDTH, 3], seed=1)
    inputs['image_j'] = tf.random_crop(
        inputs['image_j'], [model.IMG_HEIGHT, model.IMG_WIDTH, 3], seed=1)
    # inputs['image_k'] = tf.random_crop(
    #     inputs['image_k'], [model.IMG_HEIGHT, model.IMG_WIDTH, 3], seed=1 )

    inputs['image_i'] = tf.subtract(tf.div(inputs['image_i'], 127.5), 1)
    inputs['image_j'] = tf.subtract(tf.div(inputs['image_j'], 127.5), 1)
    #inputs['image_k'] = tf.subtract( tf.div( inputs['image_k'], 127.5 ), 1 )
    # Batch
    if do_shuffle is True:
        inputs['images_i'], inputs['images_j'] = tf.train.shuffle_batch(
            [inputs['image_i'], inputs['image_j']], 1, 5000, 100, seed=1)
        # inputs['images_i'], inputs['images_j'],inputs['images_k'] = tf.train.shuffle_batch(
        #     [inputs['image_i'], inputs['image_j'],inputs['image_k']], 1, 5000, 100, seed=1 )
    else:
        inputs['images_i'], inputs['images_j'] = tf.train.batch(
            [inputs['image_i'], inputs['image_j']], 1)
        # inputs['images_i'], inputs['images_j'],inputs['images_k'] = tf.train.batch(
        #     [inputs['image_i'], inputs['image_j'],inputs['image_k']],1)
    return inputs

